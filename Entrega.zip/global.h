#ifndef globalh
#define globalh

#define PIPE "/tmp/FIFOTLB"
#define FILENAME "./accesos_memoria.txt"
#define TLB_SIZE 4

#endif
